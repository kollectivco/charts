<?php

namespace Charts\Core;

/**
 * Handle automatic updates from GitHub Releases.
 * Hardened for production-grade reliability.
 */
class Updater {

	private $file;
	private $plugin_slug;
	private $basename;
	private $username;
	private $repository;
	private $github_api_result;

	public function __construct( $file ) {
		$this->file        = $file;
		$this->username    = KONTENTAINMENT_LISTS_GITHUB_OWNER;
		$this->repository  = KONTENTAINMENT_LISTS_GITHUB_REPO;
		$this->basename    = KONTENTAINMENT_LISTS_PLUGIN_BASENAME;
		$this->plugin_slug = KONTENTAINMENT_LISTS_PLUGIN_SLUG;

		$this->init();
	}

	/**
	 * Initialize the updater hooks.
	 */
	public function init() {
		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'set_transient' ) );
		add_filter( 'plugins_api', array( $this, 'set_plugin_info' ), 20, 3 );
		add_filter( 'upgrader_post_install', array( $this, 'post_install' ), 10, 3 );
	}

	/**
	 * Query the latest published release from GitHub.
	 */
	private function get_repository_info() {
		if ( ! is_null( $this->github_api_result ) ) {
			return $this->github_api_result;
		}

		$cache_key     = 'lists_github_update_check';
		$cached        = get_transient( $cache_key );
		if ( ! $cached ) {
			$cached = get_transient( 'charts_github_update_check' );
		}
		$force_refresh = ( isset( $_GET['force-check'] ) || ( isset( $_GET['action'] ) && $_GET['action'] === 'upgrade-plugin' ) );

		if ( ! $force_refresh && $cached ) {
			$this->github_api_result = $cached;
			return $cached;
		}

		$request_uri = sprintf( 'https://api.github.com/repos/%s/%s/releases/latest', $this->username, $this->repository );
		$args = array(
			'timeout' => 15,
			'headers' => array(
				'Accept'     => 'application/vnd.github.v3+json',
				'User-Agent' => 'WordPress-Lists-Updater'
			),
		);

		$response = wp_remote_get( $request_uri, $args );

		if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
			return false;
		}

		$this->github_api_result = json_decode( wp_remote_retrieve_body( $response ) );

		if ( $this->github_api_result ) {
			set_transient( $cache_key, $this->github_api_result, 2 * HOUR_IN_SECONDS );
		}

		return $this->github_api_result;
	}

	/**
	 * Inject update data into the plugins transient.
	 */
	public function set_transient( $transient ) {
		if ( empty( $transient ) || ! is_object( $transient ) ) {
			return $transient;
		}

		$repo_info = $this->get_repository_info();
		if ( ! $repo_info || empty( $repo_info->tag_name ) ) {
			return $transient;
		}

		$remote_version = ltrim( $repo_info->tag_name, 'v' );
		$local_version  = CHARTS_VERSION;

		if ( version_compare( $remote_version, $local_version, '>' ) ) {
			$package = $this->get_release_asset_url( $repo_info );
			
			if ( $package ) {
				$obj = new \stdClass();
				$obj->slug        = $this->plugin_slug;
				$obj->new_version = $remote_version;
				$obj->url         = $repo_info->html_url;
				$obj->package     = $package;
				$obj->plugin      = $this->basename;

				$transient->response[ $this->basename ] = $obj;
				
				// Also inject into the ACTUAL basename if different (to catch mismatches)
				$actual_basename = plugin_basename( $this->file );
				if ( $actual_basename !== $this->basename ) {
					$transient->response[ $actual_basename ] = $obj;
				}

				// Support installs still registered under the legacy charts basename.
				$transient->response[ KONTENTAINMENT_LISTS_LEGACY_PLUGIN_BASENAME ] = $obj;
			}
		}

		return $transient;
	}

	/**
	 * Strictly select the uploaded ZIP asset from the Release.
	 */
	private function get_release_asset_url( $repo_info ) {
		if ( empty( $repo_info->assets ) || ! is_array( $repo_info->assets ) ) {
			return false;
		}

		foreach ( $repo_info->assets as $asset ) {
			if ( isset( $asset->name ) && preg_match( '/^kontentainment-lists(?:[-_].+)?\.zip$/i', $asset->name ) ) {
				return $asset->browser_download_url;
			}

			// Look for a zip file that isn't the generic source-code zip
			if ( isset( $asset->content_type ) && $asset->content_type === 'application/zip' ) {
				return $asset->browser_download_url;
			}
			if ( isset( $asset->name ) && strpos( $asset->name, '.zip' ) !== false ) {
				return $asset->browser_download_url;
			}
		}

		return false;
	}

	/**
	 * Provide data for the "View Details" modal.
	 */
	public function set_plugin_info( $res, $action, $args ) {
		if ( 'plugin_information' !== $action ) {
			return $res;
		}

		if ( ! isset( $args->slug ) || $args->slug !== $this->plugin_slug ) {
			return $res;
		}

		$repo_info = $this->get_repository_info();
		if ( ! $repo_info ) {
			return $res;
		}

		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugin_data = get_plugin_data( $this->file );

		$res = new \stdClass();
		$res->name          = $plugin_data['Name'];
		$res->slug          = $this->plugin_slug;
		$res->version       = ltrim( $repo_info->tag_name, 'v' );
		$res->author        = '<a href="' . esc_url($plugin_data['AuthorURI']) . '">' . esc_html($plugin_data['Author']) . '</a>';
		$res->homepage      = $plugin_data['PluginURI'];
		$res->download_link = $this->get_release_asset_url( $repo_info );
		$res->last_updated  = $repo_info->published_at;
		$res->requires      = $plugin_data['RequiresWP'] ?? '5.0';
		$res->tested        = $plugin_data['TestedUpTo'] ?? '6.4';

		$res->sections = array(
			'description' => $plugin_data['Description'],
			'changelog'   => isset( $repo_info->body ) ? wp_kses_post( wpautop($repo_info->body) ) : '',
		);

		return $res;
	}

	/**
	 * Ensure the plugin folder is corrected after update.
	 */
	public function post_install( $true, $hooks, $result ) {
		global $wp_filesystem;

		$plugin_slug = KONTENTAINMENT_LISTS_PLUGIN_SLUG;
		$install_dir = $result['destination']; 

		// If the new folder name is different (e.g. charts-0.1.0 or repo-main), rename it to our fixed canonical slug
		if ( basename($install_dir) !== $plugin_slug ) {
			$new_destination = trailingslashit( $result['local_destination'] ) . $plugin_slug;
			
			if ( $wp_filesystem->exists( $new_destination ) ) {
				$wp_filesystem->delete( $new_destination, true );
			}

			$wp_filesystem->move( $install_dir, $new_destination );
			$result['destination'] = $new_destination;
		}

		$this->migrate_active_plugin_references();

		return $result;
	}

	/**
	 * Migrate active plugin references from the legacy charts basename to the new lists basename.
	 */
	private function migrate_active_plugin_references() {
		$legacy = KONTENTAINMENT_LISTS_LEGACY_PLUGIN_BASENAME;
		$new    = KONTENTAINMENT_LISTS_PLUGIN_BASENAME;

		$active_plugins = get_option( 'active_plugins', array() );
		if ( is_array( $active_plugins ) ) {
			$updated_plugins = array_map(
				static function ( $plugin ) use ( $legacy, $new ) {
					return $plugin === $legacy ? $new : $plugin;
				},
				$active_plugins
			);

			if ( $updated_plugins !== $active_plugins ) {
				update_option( 'active_plugins', $updated_plugins );
			}
		}

		$network_active = get_site_option( 'active_sitewide_plugins', array() );
		if ( is_array( $network_active ) && isset( $network_active[ $legacy ] ) ) {
			$network_active[ $new ] = $network_active[ $legacy ];
			unset( $network_active[ $legacy ] );
			update_site_option( 'active_sitewide_plugins', $network_active );
		}
	}
}
